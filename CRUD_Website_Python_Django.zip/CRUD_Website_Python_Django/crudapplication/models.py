from django.db import models

class Traveler(models.Model):
    tfname = models.CharField(max_length = 100)
    tlname = models.CharField(max_length = 100)
    tpassportno = models.CharField(max_length = 25)
    temail = models.EmailField()
    tphoneno = models.CharField(max_length = 15)
    class Meta:
        db_table = "traveler"
