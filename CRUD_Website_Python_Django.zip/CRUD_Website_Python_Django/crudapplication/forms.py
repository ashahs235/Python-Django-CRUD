from django import forms
from crudapplication.models import Traveler

class TravelerForm(forms.ModelForm):
    class Meta:
        model = Traveler
        fields = "__all__"


