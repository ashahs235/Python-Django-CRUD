from django.shortcuts import render, redirect
from crudapplication.forms import TravelerForm
from crudapplication.models import Traveler

def travel(request):  #index form action
        if request.method == "POST":
            form = TravelerForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('/show')
            else:
                return render(request, 'index.html',
                              {'form': form})
        else:
            return render(request, 'index.html')


def show(request):
    travelers = Traveler.objects.all()
    return render(request, 'show.html',{'travelers' : travelers})

def edit(request, id):
    traveler = Traveler.objects.get(id=id)
    return render(request,"edit.html",{'traveler' : traveler})

def update(request, id):
    traveler = Traveler.objects.get(id=id)
    form = TravelerForm(request.POST, instance=traveler)
    if form.is_valid():
        form.save()
        return redirect('/show')
    return render(request,"edit.html",{'traveler' : traveler})

def delete (request, id):
    traveler = Traveler.objects.get(id=id)
    traveler.delete()
    return redirect('/show')